
Core Script: amibs_auto-attribute.py
1. Modifiable Parameters: threshold, rw, rc.
2. Input: The 'sample' folder contains sample NMR spectra in CSV format.
3. Output: attribution-{sample name}.xlsx in the 'result' folder.



Usage:
1. Place your sample files in the sample folder.
2. Customize parameters in the script as needed.
3. Run the script amibs_auto-attribute.py.
4. Retrieve attribution results from the result folder.