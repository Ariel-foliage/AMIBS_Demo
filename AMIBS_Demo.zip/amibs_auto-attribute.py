# !/usr/bin/env python3
# -*- coding=utf-8 -*-

# Input：csv file of spectrum, df_sample
# Output:
#   pearsonr of [AA].xlsx (optinal)
#   attribution.xlsx

import numpy as np
import pandas as pd
import nmrglue as ng
import os
from glob import glob
from scipy.stats import pearsonr
import re

if os.path.isdir('result'):
    pass
else:
    os.mkdir('result')

# 参数    
threshold = 0.85 # similarity threshold
rw = 0.08 # range of window aim 
rc = 0.14 # range of criteria 

# 读取
p_cas = re.compile(r"./templates\\(\S*).csv") 
p_cas2 = re.compile(r"./templates/single\\(\S*).csv") # for single-peak compounds
p_sample = re.compile(r"./samples\\(\S*).csv")
files_sample = glob('./samples/*.csv')
files_template = glob('./templates/*.csv') 
files_templatesingle = glob('./templates/single/*.csv') 
df_criterias = pd.read_excel('./criterias.xlsx', header=0)

 
for file_s in files_sample:
    name_sample = p_sample.match(file_s).group(1)
    df_sample = pd.read_csv(file_s, header=0, names=['shift', 'intensity']) * 1 
    df_sample = df_sample.reset_index(drop=True)
    # Use (0.2,0.6)U(-0.2,-0.6) as baseline
    mask1 = (0.2 <= df_sample.iloc[:,0]) & (df_sample.iloc[:,0] <= 0.6)
    mask2 = (-0.6 <= df_sample.iloc[:,0]) & (df_sample.iloc[:,0] <= -0.2)
    data_bl1 = df_sample.loc[mask1]
    data_bl2 = df_sample.loc[mask2]
    data_bl = data_bl1.append(data_bl2)
    avg = np.average(data_bl.iloc[:,1]) 
    max_ = np.max(data_bl.iloc[:, 1])
    min_ = np.min(data_bl.iloc[:, 1])
    bl = max_-min_

    ##################################################
    output_rolling = []      
    col = ['cas', 'start-rolling', 'end-rolling','pi','criterion']
   
   
    for file_t in files_template:
        df_template = pd.read_csv(file_t, names=['shift', 'intensity'], dtype=np.float64) 
        name_cas = p_cas.match(file_t).group(1) 
             
        i = 0
        ls_p = [] 
        screen_rolling = []

        # locating window aim
        start = df_template['shift'].min() - rw
        end = df_template['shift'].max() + rw 
        window_aim = df_sample[(start <= df_sample['shift']) & (df_sample['shift'] <= end)]
        window_aim = window_aim.reset_index(drop=True) 
        # similarity assessment
        w_template = pd.Series(df_template['intensity'])
        rolling = window_aim.rolling(df_template.shape[0], min_periods=1)
        
        for w_ in rolling:
            if w_.shape[0] == len(w_template):
                w_rolling = pd.Series(w_['intensity'])
                pi = pearsonr(w_rolling, w_template)[0] 
                ls_p.append([i, pi])
                i = i+1
                if abs(pi) > threshold:
                    start_r = w_.iloc[0, 0]
                    end_r = w_.iloc[-1, 0]
                    screen_rolling.append([pi, start_r, end_r]) 
            else:
                pass

        # df_pi = pd.DataFrame(ls_p, columns=['window-rolling', 'pearsonr'])
        # df_pi.to_excel('./result/pearsonr_of_{}.xlsx'.format(name_cas)) # optional output
        df_screen = pd.DataFrame(screen_rolling, columns=['pi', 'start', 'end']) 
        out_r = df_screen[df_screen['pi'] == df_screen['pi'].max()] 
        
        # criteria##################################################################### 
        ls_criteria = []

        if len(screen_rolling) != 0:  
            df_cpd = df_criterias[df_criterias['cas'] == name_cas] 
            if df_cpd.shape[0] != 0:      
                groups = set(df_cpd['group'].tolist()) 
                groups = list(groups)

                for group in groups: 
                    group_cpd = df_cpd[df_cpd['group'] == group]
                    end_determin = np.max(group_cpd['criteria']) + rc
                    start_determin = np.min(group_cpd['criteria']) - rc
                    
                    w_determin = df_sample[(df_sample['shift'] >= start_determin)&(df_sample['shift'] <= end_determin)] # 在样本光谱上找到window w_determin
                    peaks = ng.peakpick.pick(data = w_determin.values, pthres=bl*3, algorithm='downward', table=False, est_params=False, cluster=False)
                    
                    if len(peaks) == 0:
                        if np.max(w_determin['intensity'].values) > bl*3:
                            ls_criteria.append('no extremum')
                        else: 
                            break #########################################
                    else: 
                        count_peaks = 0 
                        rpi_group = group_cpd['RPI'].tolist()                         
                        for peak in peaks:
                            i_peak = w_determin.iloc[peak] 
                            pi_max = df_sample[(df_sample['shift'] >= out_r.iloc[0,1])&(df_sample['shift'] <= out_r.iloc[0,2])]
                            i_pi_max = np.max(pi_max['intensity'].values)                            
                            rpi_ = i_peak / i_pi_max
                            
                            count = 0
                            for rpi_g in rpi_group:
                                if 0.8 <= (rpi_ / rpi_g) <=1.2:
                                    count = count + 1
                                else:
                                    pass
                                
                            if count >= 1:
                                ls_criteria.append(w_determin.iloc[peak[0],0]) 
                                count_peaks = count_peaks + 1
                            else:
                                pass
                        
                        if count_peaks == 0: 
                           ls_criteria.append('-')                                              
            else: 
                ls_criteria.append('no criterias')

            ####################################
            if len(ls_criteria) == 0:
                break
            else:
                output_rolling.append([name_cas, out_r.iloc[0, 1], out_r.iloc[0, 2], out_r.iloc[0, 0], ls_criteria])

    # output ############################
    df_attribute_ = pd.DataFrame(output_rolling, columns=col)
    df_attribute_.to_excel('./result/attribution-{}.xlsx'.format(name_sample))
    if df_attribute_.shape[0] == 0:
        continue
    else:
        pass

    ##single peak compounds ###########################################
    # col = ['cas', 'start-rolling', 'end-rolling','pi','criterion']
    for s in range(0, df_attribute_.shape[0]):
        s1 = df_attribute_.iloc[s,1]
        e1 = df_attribute_.iloc[s,2]
        mask1 = df_sample.loc[(df_sample.iloc[:, 0] >= s1) & (df_sample.iloc[:, 0] <= e1)]
        df_sample2 = df_sample 
        df_sample2.iloc[mask1.index, 1] = 0 
        peaks_c = df_attribute_.iloc[s,-1]
        for peak_c in peaks_c:
            if peak_c == 'no criterias' or peak_c == 'no extremum' or peak_c == '-' or peak_c == 'no signal':
                pass
            else:
                ind = df_sample2[df_sample2['shift'] == peak_c].index.tolist()
                ind_ = ind[0]                
                df_sample2.iloc[(ind_-3) : (ind_+3), 1] = 0 
              
    df_sample2 = df_sample2.reset_index(drop=True)     
    df_sample2.to_excel('./samples2/sample2-{}.xlsx'.format(name_sample)) 

    output_rolling2 = []
    for file_tsin in files_templatesingle:
        df_template = pd.read_csv(file_tsin, names=['shift', 'intensity'], dtype=np.float64) 
        name_cas = p_cas2.match(file_tsin).group(1) 
             
        i = 0
        ls_p = [] 
        screen_rolling = []

        start = df_template['shift'].min() - rw
        end = df_template['shift'].max() + rw 
        window_aim = df_sample[(start <= df_sample['shift']) & (df_sample['shift'] <= end)]
        window_aim = window_aim.reset_index(drop=True) 

        w_template = pd.Series(df_template['intensity'])
        rolling = window_aim.rolling(df_template.shape[0], min_periods=1)
        
        for w_ in rolling:
            if w_.shape[0] == len(w_template):
                w_rolling = pd.Series(w_['intensity'])
                pi = pearsonr(w_rolling, w_template)[0] 
                ls_p.append([i, pi])
                i = i+1
                if abs(pi) > threshold:
                    start_r = w_.iloc[0, 0]
                    end_r = w_.iloc[-1, 0]
                    screen_rolling.append([pi, start_r, end_r]) 
            else:
                pass

        if len(screen_rolling) == 0:
            continue 
        else:
            df_screen = pd.DataFrame(screen_rolling, columns=['pi', 'start', 'end']) 
            out_r = df_screen[df_screen['pi'] == df_screen['pi'].max()] 
            output_rolling2.append([name_cas, out_r.iloc[0, 1], out_r.iloc[0, 2], out_r.iloc[0, 0], 'single'])
    df_attribute_2 = pd.DataFrame(output_rolling2, columns=col)
      
    df_output = df_attribute_.append(df_attribute_2)
    # # cpd name in ZH
    # cas = df_output['cas'].values
    # ls_name = []
    # for cas_ in cas:
    #     name = df_[df_['cas'] == cas_].iat[0,2]
    #     ls_name.append(name)
    # df_output.insert(0,'cpd name',ls_name)
    # final output
    df_output.to_excel('./result/attribution-{}.xlsx'.format(name_sample))






